<sup class="text-black"
     role="button"
     data-controller="popover"
     data-action="click->popover#trigger"
     data-container="body"
     data-toggle="popover"
     tabindex="0"
     data-trigger="focus"
     data-placement="<?php echo e($placement); ?>"
     data-delay-show="300"
     data-delay-hide="200"
     data-bs-content="<?php echo e($content); ?>">
    <?php if (isset($component)) { $__componentOriginal385240e1db507cd70f0facab99c4d015 = $component; } ?>
<?php $component = Orchid\Icons\IconComponent::resolve(['path' => 'bs.question-lg','width' => '1em','height' => '1em'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('orchid-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Orchid\Icons\IconComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal385240e1db507cd70f0facab99c4d015)): ?>
<?php $component = $__componentOriginal385240e1db507cd70f0facab99c4d015; ?>
<?php unset($__componentOriginal385240e1db507cd70f0facab99c4d015); ?>
<?php endif; ?>
</sup>
<?php /**PATH C:\OSPanel\domains\portfoilio\portfolio\vendor\orchid\platform\resources\views/components/popover.blade.php ENDPATH**/ ?>