<svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" class="me-2" viewBox="0 0 16 16" role="img" path="bs.circle-fill" componentName="orchid-icon">
  <circle cx="8" cy="8" r="8"></circle>
</svg>
